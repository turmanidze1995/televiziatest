package com.m3u.smartphone.ui.business.channel

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import com.m3u.business.channel.ChannelViewModel
import com.m3u.core.foundation.Contracts
import com.m3u.data.database.model.isSeries
import com.m3u.data.repository.channel.ChannelRepository
import com.m3u.data.repository.playlist.PlaylistRepository
import com.m3u.data.service.MediaCommand
import com.m3u.smartphone.ui.common.helper.Helper
import com.m3u.smartphone.ui.common.internal.Toolkit
import com.m3u.smartphone.ui.material.components.Background
import com.m3u.smartphone.ui.material.model.LocalHazeState
import dagger.hilt.android.AndroidEntryPoint
import dev.chrisbanes.haze.HazeState
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class PlayerActivity : ComponentActivity() {
    private val viewModel: ChannelViewModel by viewModels()

    private val helper: Helper = Helper(this)

    companion object {
        // FIXME: the property is worked only when activity has one instance at most.
        var isInPipMode: Boolean = false
            private set

        // Televizia-ს არხების ცალკე სია M3U-ს ბაზაში (არ განახლდება ქსელიდან)
        private const val TELEVIZIA_PLAYLIST_URL = "televizia://channels"
    }

    @Inject
    lateinit var channelRepository: ChannelRepository

    @Inject
    lateinit var playlistRepository: PlaylistRepository

    @Inject
    lateinit var channelDao: com.m3u.data.database.dao.ChannelDao

    @Inject
    lateinit var playlistDao: com.m3u.data.database.dao.PlaylistDao

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        setContent {
            Toolkit(
                helper = helper,
                alwaysUseDarkTheme = true
            ) {
                val hazeState = remember { HazeState() }
                CompositionLocalProvider(LocalHazeState provides hazeState) {
                    Background(
                        color = Color.Black
                    ) {
                        ChannelRoute(
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
        addOnPictureInPictureModeChangedListener {
            isInPipMode = it.isInPictureInPictureMode
            if (!it.isInPictureInPictureMode && lifecycle.currentState !in arrayOf(
                    Lifecycle.State.RESUMED,
                    Lifecycle.State.STARTED
                )
            ) {
                viewModel.destroy()
            }
        }
    }

    private fun playFromShortcuts(channelId: Int) {
        lifecycleScope.launch {
            val channel = channelRepository.get(channelId) ?: return@launch
            val playlist = playlistRepository.get(channel.playlistUrl)
            when {
                // series can not be played from shortcuts
                playlist?.isSeries == true -> {}
                else -> {
                    helper.play(MediaCommand.Common(channel.id))
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /**
     * Televizia-ს არხის ჩართვა M3U-ს ორიგინალ ფლეიერში: არხი ინახება M3U-ს ბაზაში
     * ცალკე სიაში „Televizia“ და ირთვება ჩვეულებრივი არხივით (ფლეიერი უცვლელია).
     */
    private fun playTeleviziaChannel(url: String, title: String, logo: String?, group: String?) {
        lifecycleScope.launch {
            val playlistUrl = TELEVIZIA_PLAYLIST_URL
            if (playlistDao.get(playlistUrl) == null) {
                playlistDao.insertOrReplace(
                    com.m3u.data.database.model.Playlist(title = "Televizia", url = playlistUrl)
                )
            }
            val existing = channelDao.getByPlaylistUrlAndUrl(playlistUrl, url)
            val id = existing?.id ?: channelDao.insertOrReplace(
                com.m3u.data.database.model.Channel(
                    url = url,
                    category = group.orEmpty().ifBlank { "Televizia" },
                    title = title,
                    cover = logo?.takeIf { it.isNotBlank() },
                    playlistUrl = playlistUrl
                )
            ).toInt()
            helper.play(MediaCommand.Common(id))
        }
    }

    private fun handleIntent(intent: Intent) {
        intent.getStringExtra("televizia:url")?.takeIf { it.isNotBlank() }?.let { tvUrl ->
            playTeleviziaChannel(
                url = tvUrl,
                title = intent.getStringExtra("televizia:title").orEmpty().ifBlank { tvUrl },
                logo = intent.getStringExtra("televizia:logo"),
                group = intent.getStringExtra("televizia:group")
            )
        }
        val shortcutChannelId = intent
            .getIntExtra(Contracts.PLAYER_SHORTCUT_CHANNEL_ID, -1)
            .takeIf { it != -1 }
        val recently =
            intent.getBooleanExtra(Contracts.PLAYER_SHORTCUT_CHANNEL_RECENTLY, false)

        shortcutChannelId?.let { playFromShortcuts(it) }
        if (recently) {
            lifecycleScope.launch {
                val channel = channelRepository.getPlayedRecently() ?: return@launch
                playFromShortcuts(channel.id)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        helper.applyConfiguration()
    }

    override fun onResume() {
        super.onResume()
        viewModel.pauseOrContinue(true)
    }

    override fun onPause() {
        super.onPause()
        if (!isInPictureInPictureMode) {
            viewModel.pauseOrContinue(false)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.destroy()
    }
}
